import { useContext} from "react";
import { Contextapi } from "./Contextapi";
import { Link, useNavigate } from "react-router-dom";

function Header() {
    let navigate=useNavigate()
    const {loginname,setLoginname,cart}=useContext(Contextapi)
    function handlelogout(e){
        localStorage.removeItem('loginname')
        setLoginname(localStorage.getItem('loginname'))
        navigate('/')
    }
    
    return (
        <>
        {loginname?
        <section id="header">
            <div className="container">
                <div className="row">
                    <div className="col-md-4"><h4>Welcome {loginname} </h4></div>
                    <div className="col-md-8"><button className="btn btn-danger" onClick={(e)=>{handlelogout(e)}}>Logout</button>
                    <Link to='/cart'><button className="btn btn-warning me-3">Cart-{!cart.totalitems?0:cart.totalitems}</button></Link>
                    <Link to='/products'><button className="btn btn-info me-3">Products</button></Link>
                    </div>
                </div>
            </div>
        </section>
:
<></>
}</>
    );
}


export default Header;