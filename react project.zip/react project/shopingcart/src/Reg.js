import { useState } from "react";
import { Link } from "react-router-dom";

function Reg() {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [message, setMessage] = useState('')

    function handleform(e) {
        e.preventDefault()
        const formdata = { username, password }
        fetch('/api/reg', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formdata)
        }).then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 201) {
                setMessage(data.message)
            } else {
                setMessage(data.message)
            }
        })
    }
    return (
        <section id="login">
            <div className="container">
                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                        <h2>SingUp here ...</h2>
                        <p>{message}</p>
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label>Username</label>
                            <input type="text"
                                value={username}
                                onChange={(e) => { setUsername(e.target.value) }}
                                className="form-control" />
                            <label>Password</label>
                            <input type="text"
                                value={password}
                                onChange={(e) => { setPassword(e.target.value) }}
                                className="form-control" />
                            <button className="btn btn-success form-control mt-2">Register</button>
                        </form>
                        <p>
                            <Link to='/'>Already have account? Click here</Link>
                        </p>
                    </div>
                    <div className="col-md-4"></div>
                </div>
            </div>
        </section>
    );
}

export default Reg;