import { useState } from "react";
import Left from "./Left";

function Addproduct() {
    const [name, setName] = useState('')
    const [description, setDescription] = useState('')
    const [moredescription, setMoredescription] = useState('')
    const [price, setPrice] = useState('')
    const [quantity, setQuantity] = useState('')
    const [image, setImage] = useState('')
    const [message, setMessage] = useState('')

    function handleform(e) {
        e.preventDefault()

        const formvalues = new FormData()
        formvalues.append('name', name)
        formvalues.append('description', description)
        formvalues.append('moredescription', moredescription)
        formvalues.append('price', price)
        formvalues.append('quantity', quantity)
        formvalues.append('image', image)

        fetch('/api/addproduct', {
            method: "POST",
            body: formvalues
        }).then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 201) {
                setMessage(data.message)
            } else {
                setMessage(data.message)
            }
        })
    }

    return (
        <section id="mid">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9">
                        <h2>Add New Products Here</h2>
                        <p>{message}</p>
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label>Product Name</label>
                            <input type="text"
                                value={name}
                                onChange={(e) => { setName(e.target.value) }}
                                className="form-control" />
                            <label>Product Description</label>
                            <input type="text"
                                value={description}
                                onChange={(e) => { setDescription(e.target.value) }}
                                className="form-control" />
                            <label>Product More Description</label>
                            <textarea
                                value={moredescription}
                                onChange={(e) => { setMoredescription(e.target.value) }}
                                className="form-control"></textarea>
                            <label>Product Price</label>
                            <input type="number"
                                value={price}
                                onChange={(e) => { setPrice(e.target.value) }}
                                className="form-control" />
                            <label>Product Quantity</label>
                            <input type="number"
                                value={quantity}
                                onChange={(e) => { setQuantity(e.target.value) }}
                                className="form-control" />
                            <label>Image</label>
                            <input type="file"
                                onChange={(e) => { setImage(e.target.files[0]) }}
                                className="form-control" />
                            <button type="submit" className="form-control btn btn-success mt-2 mb-2">Add Product</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Addproduct;