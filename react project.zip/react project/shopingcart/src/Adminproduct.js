import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Adminproduct() {
    const [productdata,setProductdata]=useState([])
    useEffect(()=>{
        fetch('api/alldata').then((resp)=>{return resp.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setProductdata(data.apiData)
            }else{
                console.log(data.message)
            }
        })
    },[])

    return (
        <section id="mid">
            <div className="container">
                <div className="row">
                    <Left/>
                    <div className="col-md-9">
                        <h2>Products Management</h2>
                        <Link to="/addproduct"><button className="btn btn-info form-control">Add More Products</button></Link>
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.NO</th>
                                    <th>Product Name</th>
                                    <th>Product Description</th>
                                    <th>Product More Description</th>
                                    <th>Product Price</th>
                                    <th>Product Image</th>
                                    <th>Product Quantity</th>
                                    <th>Product Status</th>
                                    <th>Product Date</th>
                                    <th>Product Update</th>
                                </tr>
                            </thead>
                            <tbody>
                                {productdata.map((result,gg)=>(
                                    <tr>
                                    <td>{gg+1}</td>
                                    <td>{result.name}</td>
                                    <td>{result.description}</td>
                                    <td>{result.moredescription}</td>
                                    <td>{result.price}</td>
                                    <td>{result.image}</td>
                                    <td>{result.quantity}</td>
                                    <td>{result.status}</td>
                                    <td>{result.postedDate}</td>
                                    <td><Link to={`/updateproduct/${result._id}`}><button className="btn btn-info">Update</button></Link></td>
                                </tr>
                                ))}
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Adminproduct;