import {BrowserRouter as Router,Routes,Route}from 'react-router-dom'
import Login from './Login';
import Reg from './Reg';
import Dashboard from './Dashboard';
import Header from './Header';
import Footer from './Footer';
import { Contextapi } from './Contextapi';
import { useEffect, useState } from 'react';
import Adminproduct from './Adminproduct';
import Addproduct from './Addproduct';
import Updateproduct from './Updateproduct';
import Products from './Products';
import Cart from './Cart';
function App() {
  const [cart,setCart]=useState('')
useEffect(()=>{
  localStorage.setItem('cart',JSON.stringify(cart))
},[cart])
  const [loginname,setLoginname]=useState(localStorage.getItem('loginname'))
  return (
  <Router>
    <Contextapi.Provider value={{loginname,setLoginname,cart,setCart}}>
    <Header/>
  <Routes>
  <Route path='/' element={<Login/>}></Route>
  <Route path='/reg' element={<Reg/>}></Route>
  <Route path='/dashboard' element={<Dashboard/>}></Route>
  <Route path='/adminproduct' element={<Adminproduct/>}></Route>
  <Route path='/addproduct' element={<Addproduct/>}></Route>
  <Route path='/updateproduct/:id' element={<Updateproduct/>}></Route>
  <Route path='/products' element={<Products/>}></Route>
  <Route path='/cart' element={<Cart/>}></Route>
  </Routes>
  <Footer/>
  </Contextapi.Provider>
  </Router>
  );
}

export default App;