import { useParams } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Updateproduct() {
    const { id } = useParams()
    const [name, setName] = useState('')
    const [description, setDescription] = useState('')
    const [moredescription, setMoredescription] = useState('')
    const [price, setPrice] = useState('')
    const [quantity, setQuantity] = useState('')
    const [status, setStatus] = useState('')
    const [image, setImage] = useState('')
    const [message, setMessage] = useState('')
    useEffect(() => {
        fetch(`/api/singledata/${id}`).then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setName(data.apiData.name)
                setDescription(data.apiData.description)
                setMoredescription(data.apiData.moredescription)
                setPrice(data.apiData.price)
                setQuantity(data.apiData.quantity)
                setImage(data.apiData.image)
                setStatus(data.apiData.status)
            } else {
                console.log(data.message)
            }
        })
    }, [])
    function handleform(e) {
        e.preventDefault()
        console.log(image)
        let formvalues = new FormData()
        formvalues.append('name', name)
        formvalues.append('description', description)
        formvalues.append('moredescription', moredescription)
        formvalues.append('price', price)
        formvalues.append('quantity', quantity)
        formvalues.append('image', image)
        formvalues.append('status', status)

        fetch(`/api/dataupdate/${id}`, {
            method: "PUT",
            body: formvalues
        }).then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setMessage(data.message)
            } else {
                console.log(data.message)
            }
        })
    }
    return (
        <section id="mid">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9">
                        <h2>Product Update Here</h2>
                        <p>{message}</p>
                        <form onSubmit={(e) => { handleform(e) }}>
                            <label>Product Name</label>
                            <input type="text"
                                value={name}
                                onChange={(e) => { setName(e.target.value) }}
                                className="form-control" />
                            <label>Product Description</label>
                            <input type="text"
                                value={description}
                                onChange={(e) => { setDescription(e.target.value) }}
                                className="form-control" />
                            <label>Product More Description</label>
                            <textarea
                                value={moredescription}
                                onChange={(e) => { setMoredescription(e.target.value) }}
                                className="form-control"></textarea>
                            <label>Product Price</label>
                            <input type="number"
                                value={price}
                                onChange={(e) => { setPrice(e.target.value) }}
                                className="form-control" />
                            <label>Product Quantity</label>
                            <input type="number"
                                value={quantity}
                                onChange={(e) => { setQuantity(e.target.value) }}
                                className="form-control" />
                            <label>Status</label>
                            <select value={status}
                                onChange={(e) => { setStatus(e.target.value) }}
                                className="form-select">
                                <option value="OUT-STOCK">OUT Stock</option>
                                <option value="IN-STOCK">IN Stock</option>
                            </select>
                            <label>Image</label>
                            <input type="file"
                                onChange={(e) => { setImage(e.target.files[0]) }}
                                className="form-control" />
                            <button type="submit" className="form-control btn btn-success mt-2 mb-2">Add Product</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Updateproduct;