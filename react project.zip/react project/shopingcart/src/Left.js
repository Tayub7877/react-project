import { Link } from "react-router-dom";

function Left() {
    return ( 
        <div className="col-md-3">
           <Link to='/adminproduct'><button className="btn btn-warning mt-2">Product Management</button></Link>
        </div>
     );
}

export default Left;