function Footer() {
    return ( 
        <section id="footer">
            <div className="container">
                <div className="row">
                    <div className="col-md-12"><h5>footer</h5></div>
                </div>
            </div>
        </section>
     );
}

export default Footer;