import { useContext } from "react";
import { Contextapi } from "./Contextapi";

function Productstrctr(props) {
    const {pdata}=props
    const {cart,setCart}=useContext(Contextapi)
    function handlecart(e,id){
        //alert(id)
        let _cart={...cart}
        if(!_cart.items){
            _cart.items={}
        }
        if(!_cart.items[id]){
            _cart.items[id]=1            
        }else{
            _cart.items[id]+=1
        }
        if(!_cart.totalitems){
            _cart.totalitems=1
        }else{
            _cart.totalitems +=1
        }
        setCart(_cart)
        console.log(cart)
    }
    return (
        <div className="col-md-3">
            <div className="card" style={{ width: '13   rem' }}>
                <img style={{width:'100px'}} src={pdata.image} className="mx-auto card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">{pdata.name}</h5>
                    <p class="card-text">{pdata.description}</p>
                    <p>Price: {pdata.price}</p>
                    <button onClick={(e)=>{handlecart(e,pdata._id)}} className="btn btn-success me-2">Add Cart</button>
                    <button className="btn btn-danger">More Details</button>
                </div>
            </div>
        </div>
    );
}

export default Productstrctr;