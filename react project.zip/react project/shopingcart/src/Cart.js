import { useContext, useEffect, useState } from "react";
import { Contextapi } from "./Contextapi";

function Cart() {
    const {cart,setCart}=useContext(Contextapi)
    const [cartdata,setCartdata]=useState([])
    useEffect(()=>{
        fetch('/api/cart',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({ids:Object.keys(cart.items)})
            }).then((resp)=>{return resp.json()}).then((data)=>{
                //console.log(data)
                if(data.status===200){
                    setCartdata(data.apiData)
                }else{
                    console.log(data.message)
                }
        })
    },[cart])
    function handlequantity(id){
        return cart.items[id]
    }
    function handleprice(id,price){
        let tqty=handlequantity(id)
        return tqty*price
    }
    function handelinc(e,id,quantity){
        let cqty=handlequantity(id)
        if(cqty>=quantity){
            alert('you have reached to the max quantity')
            return 
        }
        let _cart={...cart}
        _cart.items[id]=cqty+1
        _cart.totalitems +=1
        setCart(_cart)
    }
    function handeldec(e,id){
        let cqty=handlequantity(id)
        if(cqty===1){
            return
        }
        let _cart={...cart}
        _cart.items[id]=cqty-1
        _cart.totalitems -=1
        setCart(_cart)
    }
    function handeledelete(e,id){
        let cqty=handlequantity(id)
        let _cart={...cart}
        delete _cart.items[id]
        _cart.totalitems -=cqty
        setCart(_cart)
    }
    return ( 
        <section id="cart">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Product Name</th>
                                    <th>Product Quantity</th>
                                    <th>Product Price</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                {cartdata.map((result,tt)=>(
                                <tr>
                                <td>{tt+1}</td>
                                <td>{result.name}</td>
                                <td><button onClick={(e)=>{handelinc(e,result._id,result.quantity)}}>+</button>{handlequantity(result._id)}<button onClick={(e)=>{handeldec(e,result._id)}}>-</button></td>
                                <td>{handleprice(result._id,result.price)}</td>
                                <td><button onClick={(e)=>{handeledelete(e,result._id)}}>Delete</button></td>
                            </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
     );
}

export default Cart;