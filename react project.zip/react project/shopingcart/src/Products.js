import { useEffect, useState } from "react";
import Productstrctr from "./Productstrctr";

function Products() {
    const [products, setProducts] = useState([])
    useEffect(() => {
        fetch('/api/productinstock').then((resp) => { return resp.json() }).then((data) => {
            //console.log(data)
            if (data.status === 200) {
                setProducts(data.apiData)
            } else {
                console.log(data.message)
            }
        })
    }, [])
    return (
        <section id="mid">
            <div className="container">
                <div className="row">
                    {products.map((result, tt) => (
                        <Productstrctr key={result._id} pdata={result}/>
                    ))}

                </div>
            </div>
        </section>
    );
}

export default Products;