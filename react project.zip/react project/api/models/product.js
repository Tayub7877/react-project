const mongoose=require('mongoose')

const productSchema=mongoose.Schema({
    name:String,
    description:String,
    moredescription:String,
    price:Number,
    image:String,
    status:{type:String,default:'IN-STOCK'},
    quantity:Number,
    postedDate:{type:Date,default:new Date}
})

module.exports=mongoose.model('product',productSchema)