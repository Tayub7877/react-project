const Reg=require('../models/reg')
const bcrypt=require('bcrypt')




exports.registration=async(req,res)=>{
    try{
    const {username,password}=req.body
    const cpass=await bcrypt.hash(password,10)
    const usercheck=await Reg.findOne({username:username})
    if(usercheck==null){
    const record=new Reg({username:username,password:cpass})
    record.save()
    res.status(201).json({
        status:201,
        message:`${username} is created succesfully`
    })
}else{
    res.status(400).json({
        status:400,
        message:`${username} is already register with us`
    })
}
    }catch(error){
        res.status(400).json({
        status:400,
        message:error.message
    })
    }
}
exports.logincheck=async(req,res)=>{
    try{
    const {username,password}=req.body
    const record=await Reg.findOne({username:username})
    if(record!==null){
        const cpass=await bcrypt.compare(password,record.password)
        if (cpass){
        res.status(200).json({
            status:200,
            apidata:record.username
        })
    }else{
        res.status(400).json({
            status:400,
            message:"Wrong Credentials"
        })
    }
    }else{
        res.status(400).json({
            status:400,
            message:"Wrong Credentials"
        })
    }
}catch(error){
    res.status(400).json({
        status:400,
        message:error.message
    })
}
}
