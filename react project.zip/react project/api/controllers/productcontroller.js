const { diskStorage } = require('multer')
const Product=require('../models/product')

exports.addproduct=(req,res)=>{
    try{
    const {name,description,moredescription,price,quantity}=req.body
    const filename=req.file.filename
    const record=new Product({name:name,description:description,moredescription:moredescription,
    price:price,quantity:quantity,image:filename})
    record.save()
    res.status(201).json({
        status:201,
        message:'Product has been added'
    })
    }catch(error){
        res.status(400).json({
            status:400,
            message:error.message
        })
    }
}
exports.alldata=async(req,res)=>{
    try{
    const record=await Product.find()
    res.status(200).json({
        status:200,
        apiData:record
    })
}catch(error){
    res.status(500).json({
        status:500,
        message:error.message
    })
}
} 
exports.singledata=async(req,res)=>{
    try{
        const id=req.params.id
        const record=await Product.findById(id)
        res.status(200).json({
            status:200,
            apiData:record
        })
    }catch(error){
        res.status(500).json({
            status:500,
            message:error.message
        })
    }
    }
exports.dataupdate=async(req,res)=>{
    try{
    const id=req.params.id
    const {name,description,moredescription,price,quantity,status}=req.body
    if(req.file){
    const filename=req.file.filename
    await Product.findByIdAndUpdate(id,{name:name,description:description,
    moredescription:moredescription,price:price,quantity:quantity,image:filename})
    }else{
        await Product.findByIdAndUpdate(id,{name:name,description:description,
        moredescription:moredescription,price:price,quantity:quantity})
    }
    res.status(200).json({
        status:200,
        message:"Successfully product updated"
    })
}catch(error){
    res.status(400).json({
        status:400,
        message:error.message
    })
}
}
exports.productinstock=async(req,res)=>{
    try{
    const record=await Product.find({status:'IN-STOCK'})
    res.status(200).json({
        status:200,
        apiData:record
    })
    }catch(error){
        res.status(500).json({
            status:500,
            message:error.message
        })
    }
}
exports.cartdata=async(req,res)=>{
    try{
    const {ids}=req.body
    const record=await Product.find({_id:{$in:ids}})
    res.status(200).json({
        status:200,
        apiData:record
    })
    }catch(error){
        res.status(500).json({
            status:500,
            message:error.message
        })
    }
}