const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const productc=require('../controllers/productcontroller')
const upload=require('../helpers/multer')


router.post('/reg',regc.registration)
router.post('/logincheck',regc.logincheck)
router.post('/addproduct',upload.single('image'),productc.addproduct)
router.get('/alldata',productc.alldata)
router.get('/singledata/:id',productc.singledata)
router.put('/dataupdate/:id',upload.single('image'),productc.dataupdate)
router.get('/productinstock',productc.productinstock)
router.post('/cart',productc.cartdata)



module.exports=router